Task 1:
 - Create markup based on "Task 1.png"
 - *Use as one background combo "gradient + background image"
 - Create markup based on "Task 2.png"
 - *Use as one background multi gradient
 